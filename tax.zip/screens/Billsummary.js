import React from 'react'
import { StyleSheet, Text, View,Image,TouchableOpacity, SafeAreaView, TextInput, Alert , StatusBar , ScrollView} from 'react-native'
import { Icon, Avatar, ListItem, Divider, CheckBox} from "react-native-elements";
import { DataTable } from 'react-native-paper';

export default function Billsummary( {navigation} ) {
    return (
        <SafeAreaView style={styles.containerstatusbar}>
          
        <StatusBar
        animated={true}
        backgroundColor="#000000"
        />
        
        <View style={styles.container}>
        <TouchableOpacity
                    onPress={() => {
                      navigation.replace("Wishlist");
                    }}
                    style={styles.goBackcontainer}
                  >
                    <Icon
                      style={styles.goBackimage}
                      name="angle-left"
                      type="font-awesome"
                      size={30}
                      color="#000000"
                    />
                  </TouchableOpacity>

              <View style={{paddingTop: 20}}></View>
       <View style={{bottom: 10}}>
            <Text style={styles.headtext}>ใบเสร็จรับเงิน</Text>
            </View>

<View style={{ flexDirection: 'row' , justifyContent: 'center'}}>
            <View style={{backgroundColor: '#7CCC92' , width:'20%' , alignItems: 'center' , paddingVertical: 8 , borderRadius: 10, right: 5}}>
                        <Text style={{}}>เล่มที่</Text>
                        <Text style={{}}>1</Text>
                    </View>
                    <View style={{backgroundColor: '#7CCC92' , width:'50%' , alignItems: 'center' , paddingVertical: 8, borderRadius: 10 ,justifyContent:'center'}}>

                        <Text style={{}}>มุสลิมพานิชณ์</Text>
                    </View>
                    <View style={{backgroundColor: '#7CCC92' , width:'20%' , alignItems: 'center' , paddingVertical: 8, borderRadius: 10, left: 5 }}>
                    <Text style={{}}>เลขที่</Text>
                        <Text style={{}}>1</Text>
                    </View>
                    
                    </View>

            <View style={{flexDirection: 'row', paddingTop: 10}}>
            <Text style={styles.bodylefttext}>นาม<Text style={styles.bodyrighttext}>    นายเอก ทองยา</Text></Text>
            <Text style={styles.bodyrighttext}> วันที่<Text style={styles.bodyrighttext}>   10/03/2564</Text></Text>
            </View>
            <View style={styles.hrname}></View>
            <View style={styles.hrdate}></View>


            <View style={{flexDirection: 'row', paddingTop: 5}}>
            <Text style={styles.bodylefttext}>ที่อยู่<Text style={{right: 10}}>   12 ต.บางนาค อ.เมือง จ.นราธิวาส</Text></Text>
            </View>
            <View style={styles.hraddress}></View>
            
            <View style={{flexDirection: 'row', paddingTop: 5}}>
            <Text style={styles.bodylefttext}>เลขที่ผู้เสียภาษี<Text style={{right: 10}}>   3456124879</Text></Text>
            </View>
            <View style={styles.hrtaxno}></View>

            <View style={{flexDirection: 'row', paddingTop: 5}}>
            <Text style={styles.bodylefttext}>เลขบัตรประจำตัวประชาชน<Text style={{right: 10}}>   1234567890456</Text></Text>
            </View>
            <View style={styles.hridcard}></View>




            <View style={{paddingTop: 40}}></View>
                    
                    <View style={{flexDirection: 'row' , paddingHorizontal: 25}}>
                    <TouchableOpacity style={styles.loginButton}> 
            <Text style={styles.loginButtonText}>เพิ่มรายการใหม่</Text>
            </TouchableOpacity>
            <View style={{paddingRight: 43}}></View>
            <TouchableOpacity style={styles.loginButton}> 
            <Text style={styles.loginButtonText}>พิมพ์</Text>
            </TouchableOpacity>
            </View>



        </View>
                 </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    containerstatusbar: {
        flex: 1,
    },
    container: {
        flex: 1,
        backgroundColor:'#D4D4D4',
    },
    goBackcontainer: {
        left: 15,
        top: 15,
      },
      goBackimage: {
        width: 30,
        height: 30,
      },
    headtext: {
        fontSize: 20,
        alignSelf: 'center',
        color: 'green'
    },
    bodylefttext: {
        fontSize: 16,
        alignSelf: 'center',
        left: 40
        
    },
    bodyrighttext: {
        fontSize: 16,
        alignSelf: 'center',
        left: 60
        
    },
    hrname: {
        width: '30%',
        height: 2,
        backgroundColor: '#444',
        left: 82,
    
    },
    hrdate: {
        width: '30%',
        height: 2,
        backgroundColor: '#444',
        left: 243,
        top: -2,
    },
    hraddress: {
        width: '68%',
        height: 2,
        backgroundColor: '#444',
        left: 85,
        top: -2,
    },
    hrtaxno: {
        width: '52%',
        height: 2,
        backgroundColor: '#444',
        left: 150,
        top: -2,
    },
    hridcard: {
        width: '33%',
        height: 2,
        backgroundColor: '#444',
        left: 228,
        top: -2,
    },
    loginButton: {
        width: '45%',
      backgroundColor: '#004FFF',
      marginTop: 30,
      paddingVertical: 10,
      borderRadius: 4,
      shadowColor: '#000',
      shadowOffset: {
        width: 2,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.5,
    },
  loginButtonText: {
      color: '#000',
      textAlign: 'center',
      fontSize:14,
      fontWeight: 'bold',
      color: '#000000',
  },
})
