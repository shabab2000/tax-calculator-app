import { NavigationContainer } from '@react-navigation/native';
import React, { useState, useEffect}from 'react'
import { SafeAreaView, StyleSheet, Text, View , StatusBar, TouchableOpacity,Image} from 'react-native'
import { Icon } from 'react-native-elements';

export default function HomeScreen({navigation}) {
  
    return (

        <View style={styles.container}>
            
            <View style={{paddingTop: 70 }}>
            <Text style={{fontSize:25,padding:25}}>เลือกบริการ</Text>
            <View style={styles.promotionViewBox}>
            <View style={styles.promotionContainer}>
            
              <TouchableOpacity style={styles.promotionBtn} onPress={() => navigation.navigate('MenuStore')}>
              <View style={{padding:5}}>
              <View style={{backgroundColor:'#fff',borderRadius:20,padding:5}}>
                <View style={{paddingLeft:20, alignItems: 'center'}}>
                  <Image source={require('./img/note.png')} style={{width: 100, height: 100}}/>
                <Text style={{fontSize: 16 , color: '#000',textAlign: 'center',padding:3}}>
                  รายรับ-รายจ่าย
                </Text>
                </View>
                </View>
                </View>
              </TouchableOpacity>
              

              <TouchableOpacity style={styles.promotionBtn} onPress={() => {}}>
              <View style={{padding:5}}>
              <View style={{backgroundColor:'#fff',borderRadius:20,padding:5}}>
              <View style={{paddingLeft:20, alignItems: 'center'}}>
                  <Image source={require('./img/budget.png')} style={{width: 100, height: 100}}/>
                <Text style={{fontSize: 16 , color: '#000',textAlign: 'center',padding:3}}>
                  คำนวณภาษี
                </Text>
                </View>
                </View>
                </View>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.promotionViewBox}>
            <View style={styles.promotionContainer}>
              
              <TouchableOpacity style={styles.promotionBtn} onPress={() => navigation.navigate('Notification')}>
              <View style={{padding:5}}>
              <View style={{backgroundColor:'#fff',borderRadius:20,padding:5}}>
              <View style={{paddingLeft:20, alignItems: 'center'}}>
                  <Image source={require('./img/notification.png')} style={{width: 100, height: 100}}/>
                <Text style={{fontSize: 18 , color: '#000',textAlign: 'center',padding:3}}>
                  การแจ้งเตือน
                </Text>
                </View>
                </View>
                </View>
              </TouchableOpacity>
              <TouchableOpacity style={styles.promotionBtn} onPress={() => {}}>
              <View style={{padding:5}}>
              <View style={{backgroundColor:'#fff',borderRadius:20,padding:5}}>
              <View style={{paddingLeft:20,alignItems: 'center'}}>
                  <Image source={require('./img/standard.png')} style={{width: 100, height: 100}}/>
                <Text style={{fontSize: 18 , color: '#000',textAlign: 'center',padding:3}}>
                  รายงานผล
                </Text>
                </View>
                </View>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          </View>
        </View>
    )
}

const styles = StyleSheet.create({
    containerstatusbar:{
        flex:1,
    },
    container:{
        flex:1,
        backgroundColor: '#eee'
      },

      promotionViewBox: {
        height: 150,
      },
      promotionContainer: {
        flexDirection: "row",
        width: "95%",
        alignSelf: "center",
      },
      promotionBtn: {
        flex: 1,
        width: "30%",
        marginHorizontal: 0,
        alignSelf: "center",
      },
      promotionIcon: {
        borderWidth: 0,
        alignItems: "center",
        alignSelf: "center",
        width: "95%",
        height: "95%",
        borderRadius: 8,
        shadowColor: "#000000",
        shadowOffset: {
          width: 2,
          height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.5,
      },
      promotionLogo: {
        width: "55%",
        height: "55%",
      },
      promotionBtnTxt: {
        alignSelf: "center",
        fontSize: 24,
        color: "#000000",
        paddingHorizontal: 5,
      },
});
