import React from 'react'
import { StyleSheet, Text, View, SafeAreaView, ScrollView , StatusBar, TextInput} from 'react-native'
import { Icon, Avatar, ListItem } from 'react-native-elements'
import BackButton from '../src/component/BackButton';

export default function Editprofile({navigation}) {
    return (
        <SafeAreaView style={styles.containerstatus}>
        <ScrollView>
            <StatusBar
                animated={true}
                backgroundColor='black'
            />
    <View style={styles.container}>
        
    <BackButton goBack={navigation.goBack} />
    
    <View style={{ alignItems: 'center', justifyContent: 'center'}}>
         <Icon 
          name='user-circle'
          type='font-awesome'
          size={100}
          color='#fff'        
        />        
    </View>
    <View style={{alignItems: 'center', justifyContent: 'center', paddingTop: 30}}>
    
    
          <Text style={styles.nameButtonText}>ฮานีรา เจ๊ะอามิ</Text>


    </View>
   
    </View>
    <Text></Text>
    
        <View>

    <ListItem bottomDivider> 
    <Icon 
        name= 'account'
        type='material-community'
        size={20}
        marginHorizontal= {3}
        />
    <ListItem.Content>
      <ListItem.Title style={{fontSize: 12}}>บัญชีของคุณ</ListItem.Title>
    </ListItem.Content>
  </ListItem>
  <View style={{paddingHorizontal: 20}}>

      <View style={{paddingTop: 40 , flexDirection: 'row', alignItems: 'center'}}>
          <Text style={{paddingHorizontal: 15}}>ชื่อ-นามสกุล</Text>
          <View style={{paddingHorizontal: 4}}></View>
          <View style={styles.inputView}>
              <Text>ฮานีรา เจ๊ะอามิ</Text><View></View>
              </View>
      </View>

      <View style={{paddingTop: 40 , flexDirection: 'row', alignItems: 'center'}}>
          <Text style={{paddingHorizontal: 15}}>E-mail</Text>
          <View style={{paddingHorizontal: 19}}></View>
          <View style={styles.inputView}>
          <Text>hanira@gmail.com</Text>
  
              
              </View>
      </View>

      <View style={{paddingTop: 40 , flexDirection: 'row', alignItems: 'center'}}>
          <Text style={{paddingHorizontal: 15}}>เบอร์โทรศัพท์</Text>
          <View style={styles.inputView}>
              <Text>0xx-xxx-xxxx</Text>
              </View>
      </View>
                
            </View>
        </View>
    </ScrollView>
    </SafeAreaView>
)
}

const styles = StyleSheet.create({
containerstatus:{
    flex:1,
    backgroundColor: '#DBE7D8'
},
container:{
    flex:1,
    paddingTop: 100,
    paddingBottom: 90,
    justifyContent: 'center'
},

logoutButtonText: {
    marginHorizontal: 12,
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',

},

nameButtonText: {
marginHorizontal: 12,
color: '#000000',
fontSize: 20,
fontWeight: 'bold',


},
nameButton: {
display: 'flex',
flexDirection: 'row',
width: '60%',
alignItems: 'center',
justifyContent: 'center',
backgroundColor: 'white',
paddingVertical: 8,
paddingHorizontal: 20,
borderRadius: 4,
elevation: 2,
shadowColor: '#000',
shadowOffset: {
width: 2,
height: 2,
},
shadowOpacity: 0.25,
shadowRadius: 3.5,
},


logisticButton: {
display: 'flex',
flexDirection: 'row',
width: '90%',
height: '80%',
backgroundColor: 'white',
paddingVertical: 15,
paddingHorizontal: 15,
borderRadius: 4,
elevation: 2,
shadowColor: '#000',
shadowOffset: {
width: 2,
height: 2,
},
shadowOpacity: 0.25,
shadowRadius: 3.5,
},
inputBox: {
    marginTop: 25,
  },
  inputLabel: {
    fontSize: 14,
    marginBottom: 6,
  },
  inputView: {
    width: '70%',
    height: 40,
    backgroundColor: '#ffffff',
    borderRadius: 4,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
},
});
