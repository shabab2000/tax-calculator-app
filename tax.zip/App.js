import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import Start from './screens/Start';
import Home from './screens/Home';
import HomeScreen from './screens/HomeScreen';
import Login from './screens/Login';
import Register from './screens/Register';
import RegisConfirm from './screens/RegisConfirm';
import Google from './screens/Google';
import Facebook from './screens/Facebook';
import Forgotpassword from './screens/Forgotpassword';
import Profile from './screens/Profile';
import Editprofile from './screens/Editprofile';
import Otp from './screens/Otp';
import Resetpassword from './screens/Resetpassword';
import Store from './screens/Store';
import MenuStore from './screens/MenuStore';
import Customer from './screens/Customer';
import Wishlist from './screens/Wishlist';
import Wishlist1 from './screens/Wishlist1';
import Billsummary from './screens/Billsummary';

const Stack = createStackNavigator();

const horizontalAnimation = {
  gestureDirection: 'horizontal',
  cardStyleInterpolator: ({ current, layouts }) => {
    return {
      cardStyle: {
        transform: [
          {
            translateX: current.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [layouts.screen.width, 0],
            }),
          },
        ],
      },
    };
  },
};

export default function App() {
  

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={horizontalAnimation}>
          <Stack.Screen name='Login' component={Login} options={{ 
        headerShown: true,
        title: 'เข้าสู่ระบบ',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>
          <Stack.Screen name='Register' component={Register} options={{ 
        headerShown: true,
        title: 'ลงทะเบียน',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>
          <Stack.Screen name='RegisConfirm' component={RegisConfirm} options={{ 
        headerShown: true,
        title: 'ลงทะเบียน',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Google' component={Google} options={{ 
        headerShown: true,
        title: 'ลงทะเบียน',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Facebook' component={Facebook} options={{ 
        headerShown: true,
        title: 'ลงทะเบียน',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

      <Stack.Screen name='Forgotpassword' component={Forgotpassword} options={{ 
        headerShown: true,
        title: 'ลืมรหัสผ่าน',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>
          
          <Stack.Screen name='Home' component={Home} options={{ 
        headerShown: false,
        title: 'Home',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='HomeScreen' component={HomeScreen} options={{ 
        headerShown: false,
        title: 'HomeScreen',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Profile' component={Profile} options={{ 
        headerShown: false,
        title: 'Profile',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Editprofile' component={Editprofile} options={{ 
        headerShown: false,
        title: 'Editprofile',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>
<Stack.Screen name='Otp' component={Otp} options={{ 
        headerShown: true,
        title: 'ยืนยันรหัส OTP',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>
<Stack.Screen name='Resetpassword' component={Resetpassword} options={{ 
        headerShown: true,
        title: 'รีเซ็ตรหัสผ่าน',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Store' component={Store} options={{ 
        headerShown: true,
        title: 'กรอกข้อมูลผู้ประกอบการ',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>
     
     <Stack.Screen name='MenuStore' component={MenuStore} options={{ 
        headerShown: true,
        title: 'รายรับ-รายจ่าย',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Customer' component={Customer} options={{ 
        headerShown: true,
        title: 'กรอกข้อมูลลูกค้า',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Wishlist' component={Wishlist} options={{ 
        headerShown: true,
        title: 'รายรับ-รายจ่าย',
          headerStyle: {
          backgroundColor: '#FFCC00'
          }}}/>

<Stack.Screen name='Wishlist1' component={Wishlist1} options={{ 
        headerShown: false,
        title: 'Wishlist1',
          headerStyle: {
          backgroundColor: '#48D1CC'
          }}}/>

<Stack.Screen name='Billsummary' component={Billsummary} options={{ 
        headerShown: false,
        title: 'Billsummary',
          headerStyle: {
          backgroundColor: '#48D1CC'
          }}}/>

      </Stack.Navigator>
    </NavigationContainer>
  );
}


